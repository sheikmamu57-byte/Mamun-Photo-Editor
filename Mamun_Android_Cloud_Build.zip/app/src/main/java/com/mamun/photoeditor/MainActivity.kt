package com.mamun.photoeditor

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.ColorMatrix as AndroidColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.content.ContentValues
import android.provider.MediaStore
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private val Ink = Color(0xFF171126)
private val Pink = Color(0xFFFF4F9A)
private val Purple = Color(0xFF8057FF)
private val Cyan = Color(0xFF35D6D0)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MamunEditor() }
    }
}

@Composable
fun MamunEditor() {
    val context = LocalContext.current
    var imageUri by remember { mutableStateOf<Uri?>(null) }
    var bitmap by remember { mutableStateOf<Bitmap?>(null) }
    var brightness by remember { mutableFloatStateOf(1f) }
    var contrast by remember { mutableFloatStateOf(1f) }
    var saturation by remember { mutableFloatStateOf(1f) }
    var blur by remember { mutableFloatStateOf(0f) }
    var selected by remember { mutableStateOf("Original") }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        imageUri = uri
        brightness = 1f; contrast = 1f; saturation = 1f; blur = 0f; selected = "Original"
    }
    LaunchedEffect(imageUri) {
        bitmap = imageUri?.let { uri ->
            withContext(Dispatchers.IO) {
                context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
            }
        }
    }

    val matrix = remember(brightness, contrast, saturation) {
        val m = ColorMatrix()
        m.setToSaturation(saturation)
        val a = m.values
        for (i in intArrayOf(0,1,2,5,6,7,10,11,12)) a[i] *= contrast
        val offset = (brightness - 1f) * 255f
        a[4] += offset; a[9] += offset; a[14] += offset
        ColorMatrix(a)
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Pink, secondary = Cyan, background = Ink, surface = Color(0xFF241B38))) {
        Column(Modifier.fillMaxSize().background(Ink).padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(46.dp).clip(RoundedCornerShape(15.dp)).background(Brush.linearGradient(listOf(Pink, Purple, Cyan))), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.AutoAwesome, null, tint = Color.White)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("MAMUN", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black)
                    Text("PHOTO EDITOR • PREMIUM", color = Cyan, fontSize = 9.sp, letterSpacing = 2.sp)
                }
                Icon(Icons.Default.Settings, null, tint = Color.LightGray)
            }
            Spacer(Modifier.height(16.dp))
            Text("Your creativity, unleashed.", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text("Make every photo feel special.", color = Color.LightGray, fontSize = 13.sp)
            Spacer(Modifier.height(14.dp))
            Box(Modifier.fillMaxWidth().weight(1f).clip(RoundedCornerShape(22.dp)).background(Color(0xFF2B2140)), contentAlignment = Alignment.Center) {
                if (bitmap == null) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.AddPhotoAlternate, null, tint = Pink, modifier = Modifier.size(54.dp))
                        Text("Add your photo", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text("Choose an image to start editing", color = Color.LightGray, fontSize = 12.sp)
                    }
                } else {
                    Image(bitmap!!.asImageBitmap(), null, modifier = Modifier.fillMaxSize().padding(8.dp), colorFilter = ColorFilter.colorMatrix(matrix))
                }
            }
            Spacer(Modifier.height(12.dp))
            Button(onClick = { picker.launch("image/*") }, modifier = Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(15.dp), colors = ButtonDefaults.buttonColors(containerColor = Pink)) {
                Icon(Icons.Default.AddPhotoAlternate, null); Spacer(Modifier.width(8.dp)); Text(if (bitmap == null) "Choose a photo" else "Change photo")
            }
            Spacer(Modifier.height(10.dp))
            Text("QUICK LOOKS", color = Color.LightGray, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                listOf("Original","Vibrant","Warm","Mono").forEach { look ->
                    FilterChip(selected == look, onClick = {
                        selected = look
                        when (look) {
                            "Original" -> { brightness=1f; contrast=1f; saturation=1f }
                            "Vibrant" -> { brightness=1.04f; contrast=1.18f; saturation=1.45f }
                            "Warm" -> { brightness=1.05f; contrast=1.08f; saturation=1.2f }
                            "Mono" -> { brightness=1f; contrast=1.12f; saturation=0f }
                        }
                    }, label = { Text(look, fontSize = 10.sp) })
                }
            }
            SliderLine("Brightness", brightness, 0.5f, 1.5f) { brightness=it; selected="Custom" }
            SliderLine("Contrast", contrast, 0.5f, 1.8f) { contrast=it; selected="Custom" }
            SliderLine("Saturation", saturation, 0f, 2f) { saturation=it; selected="Custom" }
            SliderLine("Blur", blur, 0f, 8f) { blur=it; selected="Custom" }
            OutlinedButton(onClick = {
                val source = bitmap
                if (source == null) Toast.makeText(context, "Choose a photo first", Toast.LENGTH_SHORT).show()
                else {
                    try {
                        val out = Bitmap.createBitmap(source.width, source.height, Bitmap.Config.ARGB_8888)
                        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
                        val cm = AndroidColorMatrix()
                        cm.setToSaturation(saturation)
                        val a = cm.array
                        for (i in intArrayOf(0,1,2,5,6,7,10,11,12)) a[i] *= contrast
                        val off = (brightness - 1f) * 255f
                        a[4] += off; a[9] += off; a[14] += off
                        paint.colorFilter = ColorMatrixColorFilter(cm)
                        Canvas(out).drawBitmap(source, 0f, 0f, paint)
                        val meta = ContentValues().apply {
                            put(MediaStore.Images.Media.DISPLAY_NAME, "Mamun_${System.currentTimeMillis()}.jpg")
                            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Mamun")
                        }
                        val saved = context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, meta)
                        if (saved != null) context.contentResolver.openOutputStream(saved)?.use { out.compress(Bitmap.CompressFormat.JPEG, 95, it) }
                        Toast.makeText(context, if (saved != null) "Saved in Pictures/Mamun" else "Could not save", Toast.LENGTH_LONG).show()
                        out.recycle()
                    } catch (e: Exception) { Toast.makeText(context, "Save failed", Toast.LENGTH_SHORT).show() }
                }
            }, modifier = Modifier.fillMaxWidth().height(46.dp), shape = RoundedCornerShape(14.dp)) {
                Icon(Icons.Default.SaveAlt, null); Spacer(Modifier.width(8.dp)); Text("Save edited photo")
            }
            Text("Basic photo adjustments only. Advanced AI tools are not included in this first build.", color = Color.LightGray, fontSize = 10.sp)
        }
    }
}

@Composable
fun SliderLine(label: String, value: Float, min: Float, max: Float, onChange: (Float) -> Unit) {
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, color = Color.White, fontSize = 12.sp)
            Text(String.format("%.2f", value), color = Cyan, fontSize = 11.sp)
        }
        Slider(value, onValueChange = onChange, valueRange = min..max, colors = SliderDefaults.colors(thumbColor=Pink, activeTrackColor=Purple))
    }
}
